using UnityEngine;
using UnityEngine.UI;

public class OptionsMenu : MonoBehaviour
{
    [Header("UI")]
    public Slider volumeSlider;

    const string VOLUME_KEY = "masterVolume";

    void Start()
    {
        // Cargar volumen guardado (o 1 por defecto)
        float saved = PlayerPrefs.GetFloat(VOLUME_KEY, 1f);
        if (volumeSlider)
        {
            volumeSlider.value = saved;
        }

        AudioListener.volume = saved;
    }

    // Llamado desde el Slider (On Value Changed)
    public void OnVolumeChanged(float value)
    {
        AudioListener.volume = value;
        PlayerPrefs.SetFloat(VOLUME_KEY, value);
        PlayerPrefs.Save();
    }
}
