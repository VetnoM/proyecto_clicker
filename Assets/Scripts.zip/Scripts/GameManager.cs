﻿using System.Collections.Generic;
using UnityEngine;
using TMPro;

#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem; // por si lo necesitas más tarde
#endif

public class GameManager : MonoBehaviour
{
    public static GameManager I;

    [Header("Economía")]
    public double coins = 0;              // tu “moneda”: la llamamos Clicks en UI
    public double coinsPerClick = 1;
    public double coinsPerSecond = 0;     // pasivo (si lo usas)

    [Header("UI")]
    public TextMeshProUGUI coinsText;     // mostrará: Clicks: X
    public TextMeshProUGUI cpsText;       // mostrará: CPS: Y

    // refresco UI
    float uiTimer = 0f;
    const float UI_REFRESH = 0.25f;

    // CPS manual (media móvil)
    readonly Queue<float> clickTimes = new Queue<float>();
    [SerializeField] float cpsWindowSeconds = 3f;

    public double PlayerCPS
    {
        get
        {
            float now = Time.unscaledTime;
            while (clickTimes.Count > 0 && now - clickTimes.Peek() > cpsWindowSeconds)
                clickTimes.Dequeue();
            if (cpsWindowSeconds <= 0f) return 0;
            return clickTimes.Count / (double)cpsWindowSeconds;
        }
    }

    void Awake()
    {
        if (I == null) I = this; else { Destroy(gameObject); return; }
        UpdateUI();
    }

    void Update()
    {
        if (coinsPerSecond > 0)
            coins += coinsPerSecond * Time.deltaTime;

        uiTimer += Time.deltaTime;
        if (uiTimer >= UI_REFRESH)
        {
            uiTimer = 0f;
            UpdateUI();
        }
    }

    // Click manual del botón central
    public void OnClick()
    {
        coins += coinsPerClick;
        clickTimes.Enqueue(Time.unscaledTime);

        // FX UNA sola vez, en el centro del botón
        ClickFXManager.I?.PlayClickFX($"+{coinsPerClick:0}", 36);
        // (no llamamos UpdateUI aquí para evitar tirones)
    }

    // APIs que usan los botones de mejora
    public void AddClickValue(double amount)
    {
        coinsPerClick += amount;
        if (coinsPerClick < 0) coinsPerClick = 0;
        UpdateUI();
    }

    public void AddCPS(double amount)
    {
        coinsPerSecond += amount;
        if (coinsPerSecond < 0) coinsPerSecond = 0;
        UpdateUI();
    }

    void UpdateUI()
    {
        if (coinsText) coinsText.text = $"Clicks: {coins:0}";
        if (cpsText) cpsText.text = $"CPS: {PlayerCPS:0.##}";
    }
}
