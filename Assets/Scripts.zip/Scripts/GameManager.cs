﻿using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class GameManager : MonoBehaviour
{
    public static GameManager I;

    [Header("Economía")]
    public double coins = 0;          // "Clicks" en la UI
    public double coinsPerClick = 1;  // cuánto da cada click
    public double coinsPerSecond = 0; // pasivo (factory, etc.)

    [Header("UI")]
    public TextMeshProUGUI coinsText; // "Clicks: X"
    public TextMeshProUGUI cpsText;   // "CPS: Y"

    // CPS manual del jugador (media móvil)
    readonly Queue<float> clickTimes = new Queue<float>();
    [SerializeField] float cpsWindowSeconds = 3f;

    public double PlayerCPS
    {
        get
        {
            float now = Time.unscaledTime;
            while (clickTimes.Count > 0 && now - clickTimes.Peek() > cpsWindowSeconds)
                clickTimes.Dequeue();

            if (cpsWindowSeconds <= 0f) return 0;
            return clickTimes.Count / (double)cpsWindowSeconds;
        }
    }

    void Awake()
    {
        if (I == null) I = this;
        else { Destroy(gameObject); return; }

        UpdateUI();
    }

    void Update()
    {
        // Pasivo por segundo
        if (coinsPerSecond > 0)
            coins += coinsPerSecond * Time.deltaTime;

        // UI cada frame (son solo dos textos, es barato)
        UpdateUI();
    }

    /// <summary>
    /// Click del jugador o de los agentes (misma lógica).
    /// </summary>
    public void OnClick()
    {
        coins += coinsPerClick;
        clickTimes.Enqueue(Time.unscaledTime);
        // OJO: nada de FX ni cosas pesadas aquí, solo lógica
    }

    /// <summary>
    /// Sube el valor por click (lo usan las mejoras de +1, +2, etc.).
    /// </summary>
    public void AddClickValue(double amount)
    {
        coinsPerClick += amount;
        if (coinsPerClick < 0) coinsPerClick = 0;
        UpdateUI();
    }

    /// <summary>
    /// Sube los clicks/seg pasivos (Factory, etc.).
    /// </summary>
    public void AddCPS(double amount)
    {
        coinsPerSecond += amount;
        if (coinsPerSecond < 0) coinsPerSecond = 0;
        UpdateUI();
    }

    void UpdateUI()
    {
        if (coinsText)
            coinsText.text = $"Clicks: {coins:0}";

        if (cpsText)
        {
            double totalCPS = PlayerCPS + coinsPerSecond;
            cpsText.text = $"CPS: {totalCPS:0.##}";
        }
    }
}
